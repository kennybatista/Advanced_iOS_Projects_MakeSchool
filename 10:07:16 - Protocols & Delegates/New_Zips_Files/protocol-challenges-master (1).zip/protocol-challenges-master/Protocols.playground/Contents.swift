//: Playground - noun: a place where people can play

import UIKit

protocol CanMakeNoise {
  func makeNoise()
}

class Human {
  
}

class Pig {
  
}

class Cow {
  
}


let human = Human()
let pig = Pig()
let cow = Cow()

// let arrayOfNoiseMaker: [CanMakeNoise] = [human, pig, cow]
// task: iterate through arrayOfNoiseMaker and let each object make their noise